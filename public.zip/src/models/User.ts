export interface User {
    id: number;
    name: string;
    lastName: string;
    avatar: string;
    email: string;
    balance: number;
}
